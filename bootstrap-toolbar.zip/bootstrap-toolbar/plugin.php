<?php
    class pluginHello extends Plugin {
        public function adminBodyEnd() {
            
           include('php/grid.php');
 

        }
    }
?>